- Project Problem And Goal
This program is based on the SIC implemented in Project 2.
This program has added loader, bp, progaddr, run function to the project 2 program.
By loader command, *.obj files are linked and loaded to the virtual memory.
By bp command, can make breakpoints and by run command we can execute program.

- How to Compile
source code, Makefile and the needed txt or .obj file should be in the same directory.
by putting 'make' input, we can compile.
After putting 'make', 20161598.out is made, so by putting ./2016158.out, we can execute. 

- Project Problem And Goal
This program is based on the SICs implemented in Project 1.
This program has added assemble, type, symbol function to the project 1 program.
*.obj, *.lst file is created by inputting the assembly program source file of SIC/XE, 
and We can see the symbol table made by assembly process by "symbol" function
and can watch files by "type" function.

- How to Compile
source code, Makefile and the needed txt or .asm file should be in the same directory.
by putting 'make' input, we can compile.
After putting 'make', 2015198.out is made, so by putting ./2016158.out, we can execute. 
